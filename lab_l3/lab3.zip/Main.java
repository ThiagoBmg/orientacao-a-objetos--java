import java.util.Scanner;
public class Main {
    public static void main(String[] arg){
        // // Exercicio 1
        // // No primeiro caso, o construtor deve receber 3 valores inteiros.
        // Data op1 = new Data(11,02,30);
        // op1.saida1();
        // // No segundo caso deve receber uma String e dois valores inteiros
        // Data op2 = new Data(02,"Março",30);
        // op2.saida2();
        // //  No terceiro caso deve receber dois valores inteiros, o primeiro sendo o número de dias no ano.
        // Data op3 = new Data(123, 2000);
        // op3.saida3();
        
        // // Exercicio 3
        // Scanner input = new Scanner(System.in);
        // String patientN, patientS;
        // int patientD, patientM, patientA, dc, mc, ac;
        // System.out.println("Insira a data atual");
        // System.out.print("Dia atual: ");
        // dc = input.nextInt();
        // System.out.print("Mes atual: ");
        // mc = input.nextInt();
        // System.out.print("Ano atual: ");
        // ac = input.nextInt();
        // System.out.print("Digite seu primeiro nome: ");
        // patientN = input.next();
        // System.out.print("Digire o seu sobrenome: ");
        // patientS = input.next();
        // System.out.print("qual o dia do seu nascimento: ");
        // patientD = input.nextInt();
        // System.out.print("qual o mês do seu nascimento: ");
        // patientM = input.nextInt();
        // System.out.print("qual o ano do seu nascimento: ");
        // patientA = input.nextInt();
        // HeartRates hr = new HeartRates(patientN, patientS, patientD, patientM, patientA, dc, mc, ac);
        // hr.get_result();

        // // Exercicio 4
        // Aluno ex_4 = new Aluno();
        // ex_4.setCurso("Ciência da Computação");
        // ex_4.setNome("Renato Cariani");
        // ex_4.setRA("123456789");
        // ex_4.create_response();
    }
}
