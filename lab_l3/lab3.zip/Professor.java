public class Professor {
    private String nome;
    private String departamento;

    void setNome(String nome) {
        this.nome = nome;
    }

    void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    String getNome() {
        return nome;
    }
    
    String getDepartamento() {
        return departamento;
    }
}