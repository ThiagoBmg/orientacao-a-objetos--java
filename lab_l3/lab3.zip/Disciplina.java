public class Disciplina {
    private String nome;
    private String codigo;

    void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    void setNome(String nome) {
        this.nome = nome;
    }

    String getNome() {
        return nome;
    }

    String getCodigo() {
        return codigo;
    }
}